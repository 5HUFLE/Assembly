#include <stdio.h>

int main(void)
{
    printf("Hello, Safal! \n");
    return 0;
}